dir <- system.file("examples", "demo", package = "shinyscreenshot")
setwd(dir)
shiny::shinyAppDir(".")
