dir <- system.file("examples", "demo", package = "shinydisconnect")
setwd(dir)
shiny::shinyAppDir(".")
