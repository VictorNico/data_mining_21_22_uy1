dir <- system.file("shiny", package = "ddpcr")
setwd(dir)
shiny::shinyAppDir(".")
