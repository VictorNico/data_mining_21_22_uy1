dir <- system.file("examples", "basic", package = "shinyjs")
setwd(dir)
shiny::shinyAppDir(".")
