dir <- system.file("examples", "colourInput", package = "colourpicker")
setwd(dir)
shiny::shinyAppDir(".")
