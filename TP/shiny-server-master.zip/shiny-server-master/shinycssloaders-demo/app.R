dir <- system.file("examples", "demo", package = "shinycssloaders")
setwd(dir)
shiny::shinyAppDir(".")
