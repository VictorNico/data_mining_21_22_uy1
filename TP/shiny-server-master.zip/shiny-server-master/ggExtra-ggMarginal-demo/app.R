dir <- system.file("examples", "ggMarginal", package = "ggExtra")
setwd(dir)
shiny::shinyAppDir(".")
