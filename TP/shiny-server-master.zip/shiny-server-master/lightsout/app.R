dir <- system.file("shiny", package = "lightsout")
setwd(dir)
shiny::shinyAppDir(".")
